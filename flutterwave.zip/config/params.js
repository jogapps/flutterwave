module.exports = {
    LOCAL_PORT: 3000
}